from cgi import print_directory
import csv
from itertools import count
from math import prod
import queue
import random
from re import search
from tkinter import N

item1 = []
item2 = []
product = []
recipes = []
needed = []
neededT3 = []
sell = []
shop = []
teir3 = []
teir2 = []
storage = []
Queue = []

Miracle_Dinner = ['Slimy Extract', 'Fried Shroom Plate', 'Roast Shroom Dish', 'Sweet Cookie Snack', 'Snow Cone', 'Honey Candy', 'Electro Pop', 'Herb Tea', 'Koopa Tea', 'Spaghetti Plate', 'Fried Egg', 'Spicy Soup', 'Healthy Salad', 'Space Food', 'Emergency Ration', 'Dangerous Delight', 'Inky Soup', 'Roast Horsetail', 'Hamburger', 'Peach Juice', 'Mango Juice', 'Miracle Dinner', 'Miracle Dinner', 'Miracle Dinner', 'Miracle Dinner']

with open('shop.csv', 'r') as spm_recipes: # Fills the shop list
    csv_reader = csv.reader(spm_recipes)

    for line in csv_reader:         
        shop.append(line[0])

with open('spm_r2.csv', 'r') as spm_recipes: # Fills all three lists with the solutions to all possible recipe outcomes.
    csv_reader = csv.reader(spm_recipes)     # 0 = Product, 1 = First item, 2 = Second item

    for line in csv_reader:

        if line[0] not in shop and line[1] not in shop and line[2] not in teir3:
            teir3.append(line[2])

        if line[2] not in teir3 and line[2] not in shop and line[2] not in teir2:
            teir2.append(line[2])

        item1.append(line[0])
        item2.append(line[1])
        product.append(line[2])
        recipes.append(line)

with open('96costs.csv', 'r') as spm_recipes: # Fills the 96 Needed list and their sell prices.
    csv_reader = csv.reader(spm_recipes)

    for line in csv_reader:         
        needed.append(line[0])
        sell.append(line[1])

while "Miracle Dinner" not in storage: # Fills storage with mystery box outputs
    for line in range(10):
        storage.append(random.choice(Miracle_Dinner))

def intersection(lst1, lst2): # Creates an intersection.
    lst3 = [value for value in lst1 if value in lst2]
    return lst3



neededT3 = intersection(needed, teir3)

while len(neededT3) > 0:
    search3 = random.choice(neededT3)
    print(search3)
    while search3 in neededT3:
        print(f'Checking all recipes for {search3}')
        combo = []
        for line in recipes:
            if line[2] == search3:
                combo.append(line[0])
                combo.append(line[1])
                print(f'{line[2]} = {line[1]} + {line[0]}')
        print('list successfully printed in "Combo"')
        print(combo)
        break
    break