x = {"a", "b", "c", "f"}
y = {"c", "d", "e"}
z = {"f", "g", "c"}

result = x.intersection( z)

print(result)