import csv
import random

coins = 0           # Coins will track the costs for the route.
shop = []           # Items that can be picked up on the ground or in shops.
recipe = []         # Items that require being cooked to obtain.
cooked = []         # Items that have been cooked already.
storage = []        # Items that are in storage (Max 32).
storage_count = 0   # Counts the number of items in the storage.
inventory = []      # Items carried on the person to be cooked.
inventory_count = 0 # Counts the number of items in the inventory.
queue = []          # Items that will be cooked.
item_list = []      # Holds item info such as names, IDs, and buy and sell prices.
search = None       # Spare search variable.
search = None      # Searches for item 1.
search2 = None      # Searches for item 2.
search3 = None      # Searches for product.
search_count = 0    # Counts the number of searches.
search_list = []    # List to hold searched item positions.
search_number1 = [] # List to hold searched item names. 
search_number2 = [] # List to hold searched item names.
search_number3 = [] # List to hold searched item names.
item1 = []          # List of all the first items needed in recipes.
item2 = []          # List of all the second items needed in recipes.
product = []        # List of all the products of items 1 and 2.
needed = []         # List of all 96 recipes.
sell = []           # List of all 96 recipes sell prices.
loc1 = None
loc2 = None
rotation = 0

with open('spm_r2.csv', 'r') as spm_recipes: # Fills all three lists with the solutions to all possible recipe outcomes.
    csv_reader = csv.reader(spm_recipes)     # 0 = Product, 1 = First item, 2 = Second item

    for line in csv_reader:
        item1.append(line[0])
        item2.append(line[1])
        product.append(line[2])

with open('96costs.csv', 'r') as spm_recipes: # Fills the 96 Needed list and their sell prices.
    csv_reader = csv.reader(spm_recipes)

    for line in csv_reader:         
        needed.append(line[0])
        sell.append(line[1])

with open('shop.csv', 'r') as spm_recipes: # Fills the shop list
    csv_reader = csv.reader(spm_recipes)

    for line in csv_reader:         
        shop.append(line)

def intersection(lst1, lst2):
    lst3 = [value for value in lst1 if value in lst2]
    return lst3

for line in range(4):      # just a test filling the storage with 25 random items.
    storage.append(random.choice(item1))

while len(needed) != 0: # Requires all 96 recipes to be completed.

    while len(inventory) < 10:

        # Decides where the first item will be taken from.
        if len(queue) >= 1:
            if rotation < 20:
                loc1 = queue
                search = queue[-1]
        elif len(storage) >= 1:
            loc1 = storage
            search = random.choice(loc1)
            storage.remove(search)
        else:
            loc1 = shop
            search = random.choice(loc1)

        # Decides where the second item will be taken from.
        if len(storage) >= 1:
            loc2 = storage
            search2 = random.choice(loc2)
            storage.remove(search2)
        else:
            loc2 = shop
            search2 = random.choice(loc2)

        # Check 1 #
        search_count = 0
        for line in item1:
            if search == line:
                search_number1.append(search_count)
            search_count += 1

        # Check 2 #
        search_count = 0
        for line in item2:
            if search2 == line:
                search_number2.append(search_count)
            search_count += 1

        search = intersection(search_number1, search_number2)
        if search != []:
            search = search[0]
            search3 = product[search]
        
        if search3 != None:
            if search3 in needed:
                inventory.append(search)
                inventory.append(search2)
                queue.append(search3)
                needed.remove(search3)
                search = ''
                search2 = ''
                search3 = ''
                rotation = 0
        else:
            storage.append(search)
            storage.append(search2) 
        print(inventory)
        rotation += 1
    break
