def intersection(lst1, lst2):
    return list(set(lst1) & set(lst2))
 
# Driver Code
lst5 = [9, 15]
lst6 = [9, 4, 5, 36, 47, 26, 10, 45, 87]
list3 = intersection(lst5, lst6)
print(list3)
if list3 == []:
    print('None')