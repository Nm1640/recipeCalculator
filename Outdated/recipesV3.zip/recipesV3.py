import csv
import random

coins = 0           # Coins will track the costs for the route.
shop = []           # Items that can be picked up on the ground or in shops.
recipe = []         # Items that require being cooked to obtain.
cooked = []         # Items that have been cooked already.
storage = []        # Items that are in storage (Max 32).
storage_count = 0   # Counts the number of items in the storage.
inventory = []      # Items carried on the person to be cooked.
inventory_count = 0 # Counts the number of items in the inventory.
queue = []          # Items that will be cooked.
item_list = []      # Holds item info such as names, IDs, and buy and sell prices.
search = 'name'     # Spare search variable.
search1 = 'name'    # Searches for item 1.
search2 = 'name'    # Searches for item 2.
search3 = 'name'    # Searches for product.
search_count = 0    # Counts the number of searches.
search_list = []    # List to hold searched item positions.
search_number = []    # List to hold searched item names. 
item1 = []          # List of all the first items needed in recipes.
item2 = []          # List of all the second items needed in recipes.
product = []        # List of all the products of items 1 and 2.
needed = []         # List of all 96 recipes.
sell = []           # List of all 96 recipes sell prices.
loc1 = None
with open('spm_r2.csv', 'r') as spm_recipes: # Fills all three lists with the solutions to all possible recipe outcomes.
    csv_reader = csv.reader(spm_recipes)     # 0 = Product, 1 = First item, 2 = Second item

    for line in csv_reader:
        item1.append(line[0])
        item2.append(line[1])
        product.append(line[2])

with open('96costs.csv', 'r') as spm_recipes: # Fills the 96 Needed list and their sell prices.
    csv_reader = csv.reader(spm_recipes)

    for line in csv_reader:         
        needed.append(line[0])
        sell.append(line[1])

with open('shop.csv', 'r') as spm_recipes: # Fills the shop list
    csv_reader = csv.reader(spm_recipes)

    for line in csv_reader:         
        shop.append(line)

def intersection(lst1, lst2): # Creates the intersection list between the two locations.
    return list(set(lst1) & set(lst2))

for line in range(50):      # just a test filling the storage with 25 random items.
    storage.append(random.choice(item1))

while len(needed) != 0: # Requires all 96 recipes to be completed.

    while len(queue) < 9:
        # Decides where the first item will be taken from.
        if len(queue) >= 1:
            loc1 = queue
            search1 = queue[-1]
        elif len(storage) >= 1:
            loc1 = storage
            search1 = random.choice(loc1)
        else:
            loc1 = shop
            search1 = random.choice(loc1)
        print(search1)
        
        # Check 1 #
        search_count = 0
        for line in item1:
            if search1 == line:
                search_number.append(search_count)
            search_count += 1
        print(search_number)
        break
    break



        

        
        

        


